#ifndef __USART_H
#define __USART_H

#include "stm32f10x.h"

void DMA1_Configuration(void); 
#endif //__USART_H
