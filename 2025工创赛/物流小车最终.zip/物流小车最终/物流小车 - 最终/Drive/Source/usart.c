 /***
	************************************************************************************
	*	@file  	usart.c
	*	@brief   usart 接口相关函数
   ************************************************************************************
   *  @description
	*
	*  初始化USART2的引脚 PA2/PA3，
	*  配置USART1工作在收发模式、数位8位、停止位1位、无校验、不使用硬件控制流控制，
	*  串口的波特率设置为115200，若需要更改波特率直接修改usart.h里的宏定义USART1_BaudRate。
	*  重定义fputc函数,用以支持使用printf函数打印数据
	*
	************************************************************************************
***/


#include "head.h" 
#include "stm32f10x.h"
#include <string.h>
#include <jy61p.h>
#include <stdio.h>
// 全局变量声明（供其他模块使用）
extern int32_t color_code ;
extern int32_t relative_x ;
extern int32_t relative_y ;

#define RX_BUF_SIZE 64
volatile uint8_t rx_buf[RX_BUF_SIZE];
volatile uint8_t rx_index = 0;
volatile enum {WAIT_HEADER, RECEIVING_DATA} rx_state = WAIT_HEADER;

inline int16_t mid_of_five(int16_t a, int16_t b, int16_t c,int16_t d,int16_t e);

// 自定义字符串转整数函数（支持负数）
int32_t custom_atoi(const uint8_t *str) {
    int32_t result = 0;
    int8_t sign = 1;
    
    if(*str == '-') {
        sign = -1;
        str++;
    }
    
    while(*str >= '0' && *str <= '9') {
        result = result * 10 + (*str - '0');
        str++;
    }
    return result * sign;
}

// USART2初始化
void USART2_GPIO_Config(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    // 使能时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    // 配置USART2引脚
    GPIO_InitStructure.GPIO_Pin = USART2_TX_PIN	;        // TX
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = USART2_RX_PIN	;        // RX
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 配置USART参数
    USART_InitStructure.USART_BaudRate = USART2_BaudRate;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART2, &USART_InitStructure);

    // 使能接收中断
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    
    // 配置NVIC
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART2, ENABLE);
}




//// USART2中断服务函数
//// 滤波结构体定义
//typedef struct {
//    int16_t buffer[5];      // 三级滤波缓冲区
//    int16_t filtered;       // 滤波后输出值
//    uint8_t index;          // 缓冲区索引
//} AxisFilter;

//// 全局变量声明
//extern volatile int16_t filtered_x, filtered_y; // 滤波后的最终坐标
//static AxisFilter x_filter, y_filter;    // 滤波状态机

//// USART2中断服务函数
//void USART2_IRQHandler(void) {
//   static uint8_t *p;
//    static uint8_t field_index;

//    if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
//        uint8_t data = USART_ReceiveData(USART2);

//        switch(rx_state) {
//            case WAIT_HEADER:
//                if(data == 0xFF) {
//                    rx_index = 0;
//                    rx_state = RECEIVING_DATA;
//                }
//                break;

//            case RECEIVING_DATA:
//                if(data == 0xFE) { // 收到包尾
//                    rx_buf[rx_index] = '\0';

//                    // 解析数据
//                    p = (uint8_t *)rx_buf;
//                    field_index = 0;
//                    uint8_t *fields[3] = {0};

//                    // 分割字段
//                    fields[field_index++] = p;
//                    while(*p && field_index < 3) {
//                        if(*p == ',') {
//                            *p = '\0';
//                            fields[field_index++] = ++p;
//                        } else {
//                            p++;
//                        }
//                    }

//                    // 转换数据
//                    if(field_index == 3) {
//                        color_code = custom_atoi(fields[0]);
//                        int16_t raw_x = custom_atoi(fields[1]);
//                        int16_t raw_y = custom_atoi(fields[2]);

//                        /*---- 五级滤波处理开始 ----*/
//                        // 第一级：限幅滤波（消除突发性干扰）
//                        static int16_t last_x = 0, last_y = 0;
//                        const int16_t MAX_DELTA = 50; // 最大允许变化量

//                        // X轴限幅
//                        if(abs(raw_x - last_x) > MAX_DELTA) {
//                            raw_x = last_x;
//                        }
//                        last_x = raw_x;

//                        // Y轴限幅
//                        if(abs(raw_y - last_y) > MAX_DELTA) {
//                            raw_y = last_y;
//                        }
//                        last_y = raw_y;

//                        // 第二级：中值滤波
//                        x_filter.buffer[x_filter.index] = raw_x;
//                        y_filter.buffer[y_filter.index] = raw_y;
//                        x_filter.index = (x_filter.index + 1) % 5;
//                        y_filter.index = (y_filter.index + 1) % 5;

//                        int16_t median_x = mid_of_five(x_filter.buffer[0], 
//                                                      x_filter.buffer[1], 
//                                                      x_filter.buffer[2],
//                                                      x_filter.buffer[3],
//                                                      x_filter.buffer[4]);
//                        int16_t median_y = mid_of_five(y_filter.buffer[0], 
//                                                      y_filter.buffer[1], 
//                                                      y_filter.buffer[2],
//                                                      y_filter.buffer[3],
//                                                      y_filter.buffer[4]);

//                        // 第三级：递推平均滤波
//                        const uint8_t ALPHA = 3; // 滤波系数（1/8）
//                        x_filter.filtered += (median_x << 3) - x_filter.filtered;
//                        y_filter.filtered += (median_y << 3) - y_filter.filtered;

//                        // 最终输出
//                        filtered_x = x_filter.filtered >> 3; // 除以8
//                        filtered_y = y_filter.filtered >> 3;
//                        /*---- 滤波处理结束 ----*/

//                        // 更新LCD显示（使用滤波后的数据）
//                        LCD_DisplayNumber(20, 50, custom_atoi(fields[0]), 1);  // 颜色代码
//                        LCD_DisplayNumber(20, 70, filtered_x, 3);            // X坐标
//                        LCD_DisplayNumber(20, 90, filtered_y, 3);            // Y坐标
//                    }

//                    rx_state = WAIT_HEADER;
//                } else {
//                    if(rx_index < RX_BUF_SIZE-1) {
//                        rx_buf[rx_index++] = data;
//                    } else { // 缓冲区溢出
//                        rx_state = WAIT_HEADER;
//                    }
//                }
//                break;
//        }
//    }
//}

//// 三取中值快速算法（无分支优化）
//inline int16_t mid_of_five(int16_t a, int16_t b, int16_t c, int16_t d, int16_t e) 
//{
//    int16_t min1 = (a < b) ? a : b;
//    int16_t max1 = (a < b) ? b : a;
//    int16_t min2 = (c < d) ? c : d;
//    int16_t max2 = (c < d) ? d : c;

//    int16_t min3 = (min1 < min2) ? min1 : min2;
//    int16_t max3 = (max1 < max2) ? max2 : max1;

//    int16_t mid1 = (max1 < min2) ? min2 : (min1 > max2) ? min1 : (max1 < max2) ? max1 : max2;

//    if (e < min3) {
//        return mid1;
//    } else if (e > max3) {
//        return mid1;
//    } else {
//        return e;
//    }
//}



void USART2_IRQHandler(void) {
    static uint8_t *p;
    static uint8_t field_index;
    
    if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
        uint8_t data = USART_ReceiveData(USART2);
        
        switch(rx_state) {
            case WAIT_HEADER:
                if(data == 0xFF) {
                    rx_index = 0;
                    rx_state = RECEIVING_DATA;
                }
                break;
                
            case RECEIVING_DATA:
                if(data == 0xFE) { // 收到包尾
                    rx_buf[rx_index] = '\0';
                    
                    // 解析数据
                    p = (uint8_t *)rx_buf;
                    field_index = 0;
                    uint8_t *fields[3] = {0};
                    
                    // 分割字段
                    fields[field_index++] = p;
                    while(*p && field_index < 3) {
                        if(*p == ',') {
                            *p = '\0';
                            fields[field_index++] = ++p;
                        } else {
                            p++;
                        }
                    }
                    
                    // 转换数据
                    if(field_index == 3) {
                        color_code = custom_atoi(fields[0]);
                        relative_x = custom_atoi(fields[1]);
                        relative_y = custom_atoi(fields[2]);
                        
                        // 更新LCD显示
                        LCD_DisplayNumber(20, 50, color_code, 1);    // 颜色代码
                        LCD_DisplayNumber(20, 70, relative_x, 3);    // X坐标
                        LCD_DisplayNumber(20, 90, relative_y, 3);    // Y坐标
												
                    }
                    
                    rx_state = WAIT_HEADER;
                } else {
                    if(rx_index < RX_BUF_SIZE-1) {
                        rx_buf[rx_index++] = data;
                    } else { // 缓冲区溢出
                        rx_state = WAIT_HEADER;
                    }
                }
                break;
        }
    }
}

