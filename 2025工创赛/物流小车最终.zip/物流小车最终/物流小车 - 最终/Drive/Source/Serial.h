#ifndef __SERIAL__H
#define __SERIAL__H

uint16_t  RxDate;
uint16_t Flage;
void Serial_SendByte(uint16_t Byte);
void Serial_Init();
uint16_t GeFlage(void);
uint16_t GetRxDate();


#endif
