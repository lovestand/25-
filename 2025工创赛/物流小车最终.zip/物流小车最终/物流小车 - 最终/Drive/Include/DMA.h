#ifndef __DMA__H
#define __DMA__H



void DMA1_Configuration(void); 
#endif 
