#ifndef __SERVO_H
#define __SERVO_H


void Servo_PWM1_Init(void);
void TIM3_PWM_Init(void);
void TIM3PWM_SetCompare1(u16 Compare);
void TIM3PWM_SetCompare2(u16 Compare);
void TIM3PWM_SetCompare3(u16 Compare);
void TIM3PWM_SetCompare4(u16 Compare);
void TIM1PWM_SetCompare1(u16 Compare);
void Servo_SetAngle1(float Angle1);
void Servo_SetAngle2(float Angle2);
void Servo_SetAngle3(float Angle3);
void Servo_SetAngle4(float Angle4);
void Servo_SetAngle5(float Angle5);
void servo_czero();

void TIM4_PWM_Init(void);
void TIM4PWM_SetCompare2(u16 Compare); 
//��е�۳�ʼ��
void servo_zero();
//ԭ����ץȡ
int ycatch_red(int i);
int ycatch_blue(int i);
int ycatch_green(int i);
//�ӹ�������
void jdown_red();
void jdown_blue();
void jdown_green();
//�ڶ������
void jdown_redtwo();
void jdown_bluetwo();
void jdown_greentwo();
void servo_bzero();//ʶ��ɫ��
void jcatch_onred_jgq();
void jcatch_onblue_jgq();
void jcatch_ongreen_jgq();

#endif

