#ifndef __USART4_H
#define __USART4_H

#include "stm32f10x.h"

void uart4_Init(uint32_t bound);

int mm();


#endif
