#ifndef __JY61P_H
#define __JY61P_H

#include "stm32f10x.h" 

void jy61p_ReceiveData(uint8_t RxData);

extern float Roll,Pitch,Yaw;

#endif
