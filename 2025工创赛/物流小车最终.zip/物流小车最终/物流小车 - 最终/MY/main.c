#include "head.h" 
#include <usart3.h>
#include <jy61p.h>

/**定义底盘变量**/
#define PULSES_PER_REVOLUTION 3200
#define WHEEL_DIAMETER 75
#define CAR_LENGTH 255
#define CAR_WIDTH 202	
#define POSITION_THRESHOLD 8



float M_PI = 3.14;
int rm;
int number=0;
//rxCmd[2] = 0;

/**坐标系旋转变量**/
int16_t vx,vy;

/**标志位**/
uint8_t send_complete_flagqr=0;//扫码发送完成标志
volatile uint8_t flage_catch=0;


/**定义二维码变量**/
int qr[6];
int mb,mc;

/**色块变量**/
uint8_t color_code;  //颜色代号
int relative_x;
int relative_y ;
int16_t filtered_x, filtered_y;

/**定义舵机变量**/
int yaw; //偏航角

/**定义函数变量**/
void wait_for_move_complete();
int calculate_pulses_mm(int distance_mm);     //计算距离
int calculate_single_wheel_pulses(int angle); //计算角度
void Car_Forward(int distance);//前进
void Car_Translation(int Distance);//平移
void Car_Xuanzhuan(int AG);//旋转
void modify(int asx,int asy);//调整车身
void ycatch_on_one();//第一次原料区抓取
void cdown_one();//第一次加工区放下
void ccatch_on_one();//第一次加工区抓取
void zdown_one();//第一次暂存区放置
void ycatch_on_two();//第二次原料区抓取
void cdown_two();//第二次加工区放置
void ccatch_on_two();//第二次加工区抓取
void zdown_two();//第二次暂存区放置

/***************************************************************************************************
*	函 数 名: main
*	入口参数: 无
*	返 回 值: 无
*	函数功能: 运行主程序
*	说    明: 无
***************************************************************************************************/
int main(void)
{	
	
  Servo_PWM1_Init();
  TIM3_PWM_Init();
  TIM4_PWM_Init();	
	SPI_LCD_Init();	        // LCD初始化
	uart4_Init(9600);
	USART1_GPIO_Config();   //二维码
	Usart1_Config ();       // 二维码串口初始化函数
  USART2_GPIO_Config();   //色块色环 串口
  Delay_Init();		    // 延时函数初始化
	board_init();           //USART3串口初始化
	servo_zero();           //舵机初始化位置 
	Delay_ms(3000);
	rxCmd[2] = 0;  
	while (1)
	{ 
//    servo_czero(); //回到抓取位置
//    Delay_ms(1800);	
//		for(int i=0;i<2;i++){
//	  modify(relative_x, relative_y);
//		}
	  //TIM4PWM_SetCompare2(100);

		Car_Translation(90);  //移出启停区
		Delay_ms(1000);
  	Car_Forward(300);
		Delay_ms(2000);
		Car_Translation(90);  //移出启停区
		Delay_ms(1000);
		Car_Forward(265);  //移出启停区
		Delay_ms(2000);
    QR_Code( );//二维码识别及显示

		LCD_DisplayNumber(60,10,qr[0],1);
		LCD_DisplayNumber(60,35,qr[1],1);
		LCD_DisplayNumber(60,60,qr[2],1);
		LCD_DisplayNumber(60,85,qr[3],1);
		LCD_DisplayNumber(60,105, qr[4],1);
		LCD_DisplayNumber(60,130, qr[5],1); 
		Delay_ms(200);	
//		USART_Cmd(UART4, ENABLE);//打开串口
		USART_Cmd (USART1 ,DISABLE);
		Car_Forward(840);
		Delay_ms(3000);
		TIM4PWM_SetCompare2(100);
	  ycatch_on_one();
    TIM4PWM_SetCompare2(0);		
    Delay_ms(1000);		
		//servo_zero();
		Delay_ms(1000);
		Car_Forward(415);
		Delay_ms(2500);
		Car_Xuanzhuan(90);
		Delay_ms(2500);	 	
		Car_Forward(1640);
		Delay_ms(5000);
		Car_Xuanzhuan(90);
		Delay_ms(2200);
		Car_Forward(810);
		Delay_ms(3000);
		//到达第一次加工区放下位置
		servo_czero(); //回到抓取位置
    Delay_ms(1800);	
		for(int i=0;i<2;i++){
	  modify(relative_x, relative_y);
		}
	  //modify(filtered_x,filtered_y);
		servo_zero();
		Delay_ms(500);
		cdown_one();//放置物块
		Delay_ms(1000);
		ccatch_on_one();
		Delay_ms(1000);
		servo_zero();
		Delay_ms(1000);
	   Car_Forward(-810);
		Delay_ms(3800);
		Car_Xuanzhuan(-90);
        Delay_ms(2500);
		Car_Forward(-780);
		Delay_ms(2500);
		//第一次到达暂存区
		servo_czero(); //回到抓取位置
    Delay_ms(1800);	
		for(int i=0;i<2;i++){
	  modify(relative_x, relative_y);
		}
//	  modify(filtered_x, filtered_y);
		zdown_one();
		Delay_ms(500);
		servo_zero();
		Delay_ms(1000);	
		Car_Forward(-860);
		Delay_ms(4000);
		Car_Xuanzhuan(-90);
		Delay_ms(2500);
		Car_Forward(-415);
		Delay_ms(3500);
		//第二次到达原料区，抓取
		TIM4PWM_SetCompare2(100);
		ycatch_on_two();
		TIM4PWM_SetCompare2(0);
		//servo_zero();
		Delay_ms(1000);
		Car_Forward(415);
		Delay_ms(2500);
		Car_Xuanzhuan(90);
		Delay_ms(2500);
		Car_Forward(1640);
		Delay_ms(5000);
		Car_Xuanzhuan(90);
		Delay_ms(2500);
		Car_Forward(810);//到达第二次放下位置
		Delay_ms(2500);
		//第二次到达粗加工区
		servo_czero(); //回到抓取位置
    Delay_ms(1800);	
	  for(int i=0;i<2;i++){
	  modify(relative_x, relative_y);
		}
		cdown_two();
		Delay_ms(500);
		ccatch_on_two();
		servo_zero();
		Delay_ms(1000);
	  Car_Forward(-810);
		Delay_ms(3800);
		Car_Xuanzhuan(-90);
		Delay_ms(2500);
		Car_Forward(-780);
		Delay_ms(2500);
		//第二次到达暂存区
		servo_czero(); //回到抓取位置
    Delay_ms(1800);	
	  for(int i=0;i<2;i++){
	  modify(relative_x, relative_y);
		}
		zdown_two();
		Delay_ms(500);
		servo_zero();
		Delay_ms(1000);	
		Car_Forward(-880);
		Delay_ms(4000);
		Car_Xuanzhuan(-90);
		Delay_ms(2500);
		Car_Forward(-1520);
		Delay_ms(5000);
		Car_Translation(-90);
		Delay_ms(1000);
		Car_Forward(-260);
		Delay_ms(2000);
		Car_Translation(-115);
		Delay_ms(5000);
 
   }
	
}


/**********机械臂抓取放下动作**********/
//第一次原料区抓取
void ycatch_on_one()
{
 servo_czero(); //回到抓取位置
 for(int i=0;i<3;i++)
 {
    while (color_code != qr[i]);
    switch(color_code)
   {
    case 1: ycatch_red(i); break;
	  case 2: ycatch_green(i); break;
	  case 3: ycatch_blue(i); break;
		
   }	
	  
 }
	 
}

//第二次原料区抓取
void ycatch_on_two()
{
 servo_czero(); //回到抓取位置
	Delay_ms(1000);
 for(int i=3;i<6;i++)
	{
	   while (color_code != qr[i]);
	   switch(color_code)
	  {
			 case 1: ycatch_red(i - 3); break;
			 case 2: ycatch_green(i - 3); break;
			 case 3: ycatch_blue(i - 3); break;
	  }	
	
	}
}

//第一次粗加工区放下.由于放下色块需要按任务吗顺序
void cdown_one()
{
	for(int i=0;i<3;i++)
 {
    switch(qr[i])
   {
    case 1:jdown_red(); break;
	  case 2:jdown_green(); break;
	  case 3:jdown_blue(); break;
		
   }	
	  
 }
}

//第一次粗加工区抓取
void ccatch_on_one()
{
	 for(int i=0;i<3;i++)
 {
    switch(qr[i])
   {
    case 1: jcatch_onred_jgq(); break;
	  case 2: jcatch_ongreen_jgq(); break;
	  case 3: jcatch_onblue_jgq(); break;
		
   }	 
 }

}
//第一次暂存区放下
void zdown_one()
{
for(int i=0;i<3;i++)
 {
    switch(qr[i])
   {
    case 1:jdown_red(); break;
	  case 2:jdown_green(); break;
	  case 3:jdown_blue(); break;
		
   }	
	  
 }
}
//第二次粗加工区放下
void cdown_two()
{
for(int i=3;i<6;i++)
 {
    switch(qr[i])
   {
      case 1:jdown_red(); break;
	  case 2:jdown_green(); break;
	  case 3:jdown_blue(); break;
		
   }	
	  
 }
}
//第二次粗加工区抓取
void ccatch_on_two()
{
	 for(int i=3;i<6;i++)
 {
    switch(qr[i])
   {
      case 1: jcatch_onred_jgq(); break;
	  case 2: jcatch_ongreen_jgq(); break;
	  case 3: jcatch_onblue_jgq(); break;
		
   }	
	  
 }
}
//第二次暂存区放下
void zdown_two()
{
for(int i=3;i<6;i++)
 {
    switch(qr[i])
   {
      case 1:jdown_redtwo(); break;
	  case 2:jdown_greentwo(); break;
	  case 3:jdown_bluetwo(); break;
		
   }	
	  
 }
}



// 计算所需脉冲数的函数（以毫米为单位）
int calculate_pulses_mm(int distance_mm) //前进
	{
    double circumference_mm = M_PI * WHEEL_DIAMETER; // 轮子周长，单位：毫米
    double revolutions = distance_mm / circumference_mm; // 轮子需要转的圈数
    double total_angle_degrees = revolutions * 360.0; // 总角度，单位：度
    int pulses_needed = (int)(total_angle_degrees  * 8.89);
 
    return pulses_needed;
}
	
// 车辆参数宏定义
#define VEHICLE_LENGTH      0.236f    // 车长（米）
#define VEHICLE_WIDTH       0.2f     // 车宽（米）
#define WHEEL_DIAMETER      0.075f   // 轮子直径（米）
#define ROLLER_ANGLE        45.0f    // 辊子角度（度）

int calculate_single_wheel_pulses(int angle) {
    // 计算几何半径r = √( (L/2)² + (W/2)² )
    const float half_length = VEHICLE_LENGTH / 2.0f;
    const float half_width = VEHICLE_WIDTH / 2.0f;
    const float r = sqrtf(half_length*half_length + half_width*half_width);

    // 角度转弧度
    const float theta_rad = angle * (float)(M_PI / 180.0f);

    // 计算cos(45°)
    const float cos_alpha = cosf(ROLLER_ANGLE * (float)(M_PI / 180.0f));

    // 计算基础脉冲数（绝对值）
    const float pulse_float = (theta_rad * r * 3200) 
                            / (M_PI * WHEEL_DIAMETER * cos_alpha);

    // 四舍五入取整
    const int32_t pulse = (int32_t)roundf(pulse_float);
		
		 return pulse;
	}








void Car_Forward(int distance)
{ 
  int mc;
  if(distance >= 0 ){
	mc=calculate_pulses_mm(distance);
	Emm_V5_Pos_Control(1, 0, 200, 30, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(2, 0, 200, 30, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(3, 1, 200, 30, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(4, 1, 200, 30, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(10);
  }
  else {
	mc=calculate_pulses_mm(abs(distance));
  Emm_V5_Pos_Control(1, 1, 200, 30, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(2, 1, 200, 30, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(3, 0, 200, 30, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(4, 0, 200, 30, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(10);
  }
}

void Car_Xuanzhuan(int AG)
{
  s16 jd;
  if(AG>=0){
	jd=calculate_single_wheel_pulses(AG);//正值逆时针
	Emm_V5_Pos_Control(1, 1, 100, 10, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(2, 1, 100, 10, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(3, 1, 100, 10, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(4, 1, 100, 10, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(10);
  }
  else{
  jd=calculate_single_wheel_pulses(abs(AG));//负值顺时针
	Emm_V5_Pos_Control(1, 0, 100, 10, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(2, 0, 100, 10, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(3, 0, 100, 10, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(4, 0, 100, 10, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(10);
  }
}


void Car_Translation(int Distance)
{ 
  s16 MC;
  if(Distance>=0){
	MC=calculate_pulses_mm(Distance);
	Emm_V5_Pos_Control(1, 0, 100, 10, MC,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(2, 1, 100, 10, MC,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(3, 1, 100, 10, MC,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(4, 0, 100, 10, MC,0, 1);
	Delay_ms(10);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(10);
  }
  else{
    MC=calculate_pulses_mm(abs(Distance));
	Emm_V5_Pos_Control(1, 1, 100, 10, MC,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(2, 0, 100, 10, MC,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(3, 0, 100, 10, MC,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(4, 1, 100, 10, MC,0, 1);
	Delay_ms(10);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(10);
  
  }
}

/**调整小车车身**/
// 调整小车车身

void modify(int asx, int asy) {
//    if(asy>0) vx=asy/10*1.2;
//    else vx = asy*1.2;  // 示例中的固定偏移量
//    vy = asx*1.2;
    if (color_code == 2) {
        // 计算坐标偏移量
//			if(asy>0) vx= asy * 1.2;
//      else vx = asy*1.2;  // 示例中的固定偏移量
			vx = asy*1.2+16; 
      vy = asx*1.2-15;

        // 判断条件是否满足
        bool need_translate = abs(vy) >= POSITION_THRESHOLD;
        bool need_forward = abs(vx) >= POSITION_THRESHOLD;

        // 条件分支处理
        if (need_translate && need_forward) {
            // 场景1：两个条件都满足，顺序执行
					  Car_Forward(vx);
				  	//wait_for_move_complete();
					  LCD_DisplayNumber(120,70,1 ,2);
            Delay_ms(2000);  // 等待前进完成
					
            Car_Translation(vy);
					  LCD_DisplayNumber(120,50,2 ,2);
					  //wait_for_move_complete();
            Delay_ms(2000);  // 等待平移完成
            
					  
        } else {
            // 场景2：单独处理每个条件
            if (need_translate) {
                Car_Translation(vy);
							  LCD_DisplayNumber(120,90,3 ,2);
							  //wait_for_move_complete();
                Delay_ms(2000);
            }
            if (need_forward) {
                Car_Forward(vx);
							  LCD_DisplayNumber(120,110,4,2);
							  //wait_for_move_complete();
                Delay_ms(2000);
            }
        }
				 LCD_DisplayNumber(120,50,0,2);
				 LCD_DisplayNumber(120,70,0,2);
				 LCD_DisplayNumber(120,90,0,2);
				 LCD_DisplayNumber(120,110,0,2);
    }
}


//void modify(int16_t asx, int16_t asy) {
//    // 常量定义，例如：
//    // 检查是否识别到绿色圆环（代号为 2）
//	  int t=0;
//    if(color_code == 2 ) {
//        // 根据坐标情况调整 vx 和 vy 的值
//        vx = asy+5.5;
//        vy = asx;
////			  USART_Cmd (USART2 ,DISABLE);

//        // 循环直到 vx 和 vy 的绝对值都小于 POSITION_THRESHOLD
//            // 检查 x 坐标是否超出阈值
//            if (abs(vy) >= POSITION_THRESHOLD) {
//                // 调用 Car_Forward 函数控制小车左右平移
//                //Car_Forward(vx);
//							  Car_Translation(vy);
//                // 等待小车移动到指定位置
//				        Delay_ms(2000);
////                wait_for_move_complete();
//							  t=1;
//            }

//            // 检查 y 坐标是否超出阈值
//            if (abs(vx) >= POSITION_THRESHOLD && t==1) 
//							{
//                // 调用 Car_Translation 函数控制小车前后移动
//								Car_Forward(vx);
//                //Car_Translation(vy);
//                // 等待小车移动到指定位置
//				        Delay_ms(2000);
//								t=0;
////                wait_for_move_complete();
//            }
//    }
//}


void wait_for_move_complete() {
    // 持续检查 rxcmd[2] 的值
    while (rxCmd[2] != 0x9F); //{
        // 可以添加适当的延时，避免 CPU 占用过高
        // 例如，使用 Delay_ms 函数进行延时
//      Delay_ms(10); 
//			LCD_DisplayNumber(120,70, rxCmd[2],4);
//    }
    // 当 rxcmd[2] 等于 159 时，将其置为 0，以便下次使用
	  number+=1;
    rxCmd[2] = 0;
		LCD_DisplayNumber(120,50, number,4);
		
}


